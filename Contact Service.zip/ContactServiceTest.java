import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.Assert.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);

        assertEquals(contact, contactService.getContact("1"));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        // Verify that the contact exists before deletion
        assertNotNull(contactService.getContact("1"));

        // Delete the contact
        contactService.deleteContact("1");

        // Verify that the contact no longer exists after deletion
        assertThrows(IllegalArgumentException.class, () -> contactService.getContact("1"));
    }


    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.updateContactFields("1", "Jane", null, "9876543210", null);

        Contact updatedContact = contactService.getContact("1");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Doe", updatedContact.getLastName());  //no update
        assertEquals("9876543210", updatedContact.getPhone());
        assertEquals("123 Main St", updatedContact.getAddress());//no update
    }
}

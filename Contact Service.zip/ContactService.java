import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    public void addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Invalid contact or duplicate contact ID.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    public void deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.remove(contactId);
    }

    public void updateContactFields(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }

        Contact existingContact = contacts.get(contactId);

        // Update fields if provided (non-null) values
        if (firstName != null) {
            existingContact.setFirstName(firstName);
        }
        if (lastName != null) {
            existingContact.setLastName(lastName);
        }
        if (phone != null) {
            existingContact.setPhone(phone);
        }
        if (address != null) {
            existingContact.setAddress(address);
        }
    }

    public Contact getContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        return contacts.get(contactId);
    }

   
}


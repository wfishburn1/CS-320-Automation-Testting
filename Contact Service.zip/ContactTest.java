import org.junit.Test;
import static org.junit.Assert.fail;

public class ContactTest {

    @Test
    public void testInvalidContactId() {
        // Invalid contact ID (null)
        try {
            new Contact(null, "John", "Doe", "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
        // Invalid contact ID (exceeds 10 characters)
        try {
            new Contact("12345678900", "John", "Doe", "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
    }

    @Test
    public void testInvalidFirstName() {
        // Invalid first name (null)
        try {
            new Contact("1", null, "Doe", "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
        	String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
        // Invalid first name (exceeds 10 characters)
        try {
            new Contact("1", "exceedingcharname", "Doe", "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
        	String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
    }
    
    @Test
    public void testInvalidLastName() {
        // Invalid last name (null)
        try {
            new Contact("1", "John", null, "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
        // Invalid last name (exceeds 10 characters)
        try {
            new Contact("1", "John", "exceedingcharlength", "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
    }
    
    @Test
    public void testInvalidPhone() {
        // Invalid phone (null)
        try {
            new Contact("1", "John", "Doe", null, "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }

        // Invalid phone (length is not 10)
        try {
            new Contact("1", "John", "Doe", "123456789", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
    }

    @Test
    public void testInvalidAddress() {
    	// Invalid address (null)
        try {
            new Contact("1", "John", "Doe", "1234567890", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
        	String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
        	
    	// Invalid address (length exceeds limit)
        try {
            new Contact("1", "John", "Doe", "1234567890", "123 Main St, City, Country, exceeding characters");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
        	String errorMessage = e.getLocalizedMessage();
            System.out.println(errorMessage);
        }
    }
}
